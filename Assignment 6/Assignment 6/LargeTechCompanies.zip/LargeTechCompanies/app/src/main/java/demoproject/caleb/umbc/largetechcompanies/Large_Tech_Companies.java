package demoproject.caleb.umbc.largetechcompanies;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class Large_Tech_Companies extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_large__tech__companies);
    }
}
