package Problem_15_1;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.control.Button;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.HBox;
import javafx.stage.Stage;

import java.awt.*;
import java.util.ArrayList;
import java.util.Random;

import static javafx.geometry.Orientation.HORIZONTAL;

public class run extends Application{
    private FlowPane cards = new FlowPane();
    private Random rndm = new Random();
    private HBox button = new HBox();
    private BorderPane pane = new BorderPane();

    @Override
    public void start(Stage primaryStage) throws Exception {
        cards.setOrientation(HORIZONTAL);
        getHand(cards);

        Button btRef = new Button("Refresh");
        btRef.setOnAction(e -> getHand(cards));
        button.getChildren().add(btRef);

        pane.setCenter(cards);
        pane.setBottom(button);

        Scene scene = new Scene(pane);
        primaryStage.setTitle("5 Card Hand");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    public ArrayList getDeck() {
        ArrayList deck = new ArrayList();
        for (int i = 0; i < 52; i++) {
            deck.add(i + 1);
        }
        return deck;
    }

    public void getHand(FlowPane cards){
        ArrayList deck = new ArrayList();
        deck = getDeck();
        cards.getChildren().clear();

        for (int j = 0; j < 5; j++){
            cards.getChildren().add(new ImageView((new Image("card/" + deck.get((int) rndm.nextInt(51) + 1) + ".png"))));
        }
    }

    public static void main(String[] args) {
        launch(args);
    }

}
