package Problem_15_19;

import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.input.MouseButton;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.stage.Stage;

import java.util.Random;

public class Whack_a_Mole extends Application {
    Pane pane = new Pane();
    static int count = 0;
    Label dispCount = new Label("Current Count: " + count);
    Circle circle = new Circle();
    Long start = System.currentTimeMillis();

    @Override
    public void start(Stage primaryStage) throws Exception {
        pane.setMaxSize(500,500);
        pane.setMinSize(500,500);
        newCircle();
        pane.getChildren().add(circle);

        dispCount.setAlignment(Pos.TOP_LEFT);
        pane.getChildren().add(dispCount);

        circle.setOnMouseClicked(e ->
        {
            if (e.getButton() == MouseButton.PRIMARY) {
                if (circle.contains(e.getX(), e.getY())) {
                    if (count < 20){
                        pane.getChildren().remove(circle);
                        newCircle();
                        pane.getChildren().add(circle);
                        count++;
                        pane.getChildren().remove(dispCount);
                        dispCount = new Label("Current Count: " + count);
                        pane.getChildren().add(dispCount);
                    }
                    else{
                        Long stop = System.currentTimeMillis();
                        pane.getChildren().remove(circle);
                        pane.getChildren().remove(dispCount);
                        Long time = (stop - start) / 1000 ;
                        Label label = new Label("It has taken you " + time + " seconds ");
                        label.setAlignment(Pos.CENTER);
                        pane.getChildren().add(label);

                    }
                }
            }

        });

        Scene scene = new Scene(pane, 500, 500);
        primaryStage.setTitle("Whack-a-Mole");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    public void newCircle(){

        Random rand = new Random();
        int r = rand.nextInt(256);
        int g = rand.nextInt(256);
        int b = rand.nextInt(256);

        circle.setCenterY((Math.random() * 450) + 10);
        circle.setCenterX((Math.random() * 450) + 10);
        circle.setRadius(10);
        circle.setFill(Color.rgb(r, g, b));
    };

    private class makeCircle extends Pane{



    }

    public static void main(String[] args) { launch(args); }
}
