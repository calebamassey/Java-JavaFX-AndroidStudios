package Problem_15_5;

import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

public class Investment_Calculator extends Application {
    private TextField investmentAmount = new TextField();
    private TextField annualIR = new TextField();
    private TextField numYears = new TextField();
    private TextField futureValue = new TextField();
    private Button btCalculate = new Button("Calculate");

    @Override
    public void start(Stage primaryStage) throws Exception {
        GridPane pane = new GridPane();
        pane.setHgap(5);
        pane.setVgap(5);

        pane.add(new Label("Investment Amount"), 0, 0);
        pane.add(investmentAmount, 1, 0);
        pane.add(new Label("Annual Interest Rate"), 0, 1);
        pane.add(annualIR, 1, 1);
        pane.add(new Label("Years"), 0, 2);
        pane.add(numYears, 1,2);
        pane.add(new Label("Future Value"), 0, 3);
        pane.add(futureValue, 1, 3);
        pane.add(btCalculate, 1, 4);

        btCalculate.setOnAction(e -> futureValue());

        pane.setAlignment(Pos.CENTER);
        futureValue.setEditable(false);

        Scene scene = new Scene(pane, 500, 500);
        primaryStage.setTitle("Future Value Calculator");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    public void futureValue() {
        double investment = Double.parseDouble(investmentAmount.getText());
        double interestRate = Double.parseDouble(annualIR.getText());
        double years = Double.parseDouble(numYears.getText());
        futureValue.setText(Double.toString(investment * Math.pow((1 + interestRate),(years))));
    }

    public static void main(String[] args) {  launch(args);  }
}
