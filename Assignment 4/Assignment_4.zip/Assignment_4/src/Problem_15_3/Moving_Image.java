package Problem_15_3;

import javafx.application.Application;
import javafx.scene.image.ImageView;
import javafx.geometry.Orientation;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
import java.awt.*;

public class Moving_Image extends Application {
    @Override
    public void start(Stage primaryStage) throws Exception {

        ImageObj image = new ImageObj(200, 200, 20);

        Button btUP = new Button("Up");
        Button btDOWN = new Button("Down");
        Button btLEFT = new Button("Left");
        Button btRIGHT = new Button("Right");

        btUP.setOnAction(e -> image.Up());
        btDOWN.setOnAction(e -> image.Down());
        btLEFT.setOnAction(e -> image.Left());
        btRIGHT.setOnAction(e -> image.Right());

        FlowPane buttons = new FlowPane();
        buttons.setOrientation(Orientation.HORIZONTAL);
        buttons.setAlignment(Pos.CENTER);
        buttons.getChildren().add(btUP);
        buttons.getChildren().add(btDOWN);
        buttons.getChildren().add(btLEFT);
        buttons.getChildren().add(btRIGHT);

        BorderPane pane = new BorderPane();
        pane.setCenter(image);
        pane.setBottom(buttons);

        Scene scene = new Scene(pane, 500, 500);
        primaryStage.setScene(scene);
        primaryStage.setTitle("Moving Ball");
        primaryStage.show();
    }

    private class ImageObj extends Pane {

        ImageView imageView = new ImageView("smiley.gif");

        ImageObj() {
            imageView.setX(0);
            imageView.setY(0);
            imageView.setFitWidth(20);
        }

        ImageObj(double centerX, double centerY, double size){

            imageView.setX(centerX);
            imageView.setY(centerY);
            imageView.setFitHeight(size);
            getChildren().add(imageView);
        }

        public void Up() {
            if (imageView.getY() - (imageView.getFitHeight()) < imageView.getFitHeight() ){
                return;
            }
            imageView.setY(imageView.getY() - 5);
        }

        public void Down() {
            if (imageView.getY() + (imageView.getFitHeight()) > getHeight()){
                return;
            }
            imageView.setY(imageView.getY() + 5);
        }

        public void Left() {
            if (imageView.getX() - (imageView.getFitHeight()) < imageView.getFitHeight() ){
                return;
            }
            imageView.setX(imageView.getX() - 5);
        }

        public void Right() {
            if (imageView.getX() + (imageView.getFitHeight()) > getWidth()){
                return;
            }
            imageView.setX(imageView.getX() + 5);
        }

    }

    public static void main(String[] args) {
        launch(args);
    }
}
