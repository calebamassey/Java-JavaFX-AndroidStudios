package Problem_15_15;

import javafx.animation.FillTransition;
import javafx.application.Application;
import javafx.collections.ObservableList;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.input.MouseButton;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.stage.Stage;
import javafx.util.Duration;

import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.ArrayList;

public class Points extends Application {
    Pane pane = new Pane();
    @Override
    public void start(Stage primaryStage) throws Exception {
        pane.setOnMouseClicked(e -> {

            if (e.getButton() == MouseButton.PRIMARY) {
                pane.getChildren().add(makeCircle(e.getX(), e.getY()));
            }
            else{
                removeCircle(e.getX(), e.getY());
            }
        });


        Scene scene = new Scene(pane, 500,500);
        primaryStage.setTitle("Point and Click");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    public Circle makeCircle(double centerX, double centerY){
        Circle circle = new Circle();
        circle.setCenterX(centerX);
        circle.setCenterY(centerY);
        circle.setRadius(5);

        FillTransition color = new FillTransition(Duration.millis(300), circle, Color.RED, Color.BLANCHEDALMOND);
        color.setAutoReverse(true);
        color.setCycleCount(1000);

        color.play();

        return circle;
    }

    public void removeCircle(double centerX, double centerY){
        ObservableList<Node> children = pane.getChildren();
        for (int i = 0; i < children.size(); i++){
            Node circle = children.get(i);
            if(circle.contains(centerX, centerY) && circle instanceof Circle){
                pane.getChildren().remove(circle);
                break;
            }
        }

    }

    public static void main(String[] args) { launch(args);    }
}
