package Problem_15_28;

import javafx.animation.KeyFrame;
import javafx.animation.KeyValue;
import javafx.animation.PathTransition;
import javafx.animation.Timeline;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.shape.Arc;
import javafx.scene.shape.ArcType;
import javafx.scene.shape.Circle;
import javafx.stage.Stage;
import javafx.util.Duration;

import java.util.ArrayList;

public class Fan extends Application {
    ArrayList bladeList = new ArrayList();
    BorderPane pane  = new BorderPane();
    Circle circle = new Circle();
    Arc blade = new Arc();
    Pane fan = new Pane();
    HBox buttons = new HBox();
    Timeline motion;


    @Override
    public void start(Stage primaryStage) throws Exception {

        createFan();

        motion = new Timeline(new KeyFrame(Duration.millis(50), e -> Rotate()));
        motion.setCycleCount(Timeline.INDEFINITE);
        motion.play();

        Button btRun = new Button("Resume");
        Button btPause = new Button("Pause");
        Button btReverse = new Button("Reverse");

        btRun.setOnAction(e -> Run());
        btPause.setOnAction(e -> Pause());
        btReverse.setOnAction(e -> Reverse());

        buttons.getChildren().add(btRun);
        buttons.getChildren().add(btReverse);
        buttons.getChildren().add(btPause);

        buttons.setAlignment(Pos.CENTER);
        pane.setBottom(buttons);

        Scene scene = new Scene(pane, 500, 500);
        primaryStage.setScene(scene);
        primaryStage.setTitle("Moving Fan");
        primaryStage.show();

    }

    public void createFan(){
        circle.setRadius(50);
        circle.setStroke(Color.BLACK);
        circle.setFill(Color.WHITE);
        circle.setCenterX(250);
        circle.setCenterY(250);

        pane.getChildren().add(circle);

        createBlades();
    }

    public void createBlades() {
        for (int i = 0; i < 4; i++) {
            switch (i){
                case 0:
                    blade = new Arc(250, 250, 45, 45, 90, 40);
                    blade.setStroke(Color.BLACK);
                    blade.setFill(Color.BLACK);
                    blade.setType(ArcType.ROUND);
                    bladeList.add(blade);
                    fan.getChildren().add(blade);
                    break;
                case 1:
                    blade = new Arc(250, 250, 45, 45, 180, 40);
                    blade.setStroke(Color.BLACK);
                    blade.setFill(Color.BLACK);
                    blade.setType(ArcType.ROUND);
                    bladeList.add(blade);
                    fan.getChildren().add(blade);
                    break;
                case 2:
                    blade = new Arc(250, 250, 45, 45, 270, 40);
                    blade.setStroke(Color.BLACK);
                    blade.setFill(Color.BLACK);
                    blade.setType(ArcType.ROUND);
                    bladeList.add(blade);
                    fan.getChildren().add(blade);
                    break;
                case 3:
                    blade = new Arc(250, 250, 45, 45, 360, 40);
                    blade.setStroke(Color.BLACK);
                    blade.setFill(Color.BLACK);
                    blade.setType(ArcType.ROUND);
                    bladeList.add(blade);
                    fan.getChildren().add(blade);
                    break;
            }
        }
        pane.getChildren().add(fan);
    }


        public void Run(){
            motion.pause();
            motion = new Timeline(new KeyFrame(Duration.millis(50), e -> Rotate()));
            motion.setCycleCount(Timeline.INDEFINITE);
            motion.play();
        }


        public void Pause(){
            motion.pause();
        }


        public void Reverse(){
            motion.pause();
            motion = new Timeline(new KeyFrame(Duration.millis(50), e -> ReverseRotate()));
            motion.setCycleCount(Timeline.INDEFINITE);
            motion.play();
        }

        public void Rotate(){
                for (int i = 0; i < 4; i++) {
                    Arc a = (Arc)bladeList.get(i);
                    a.setStartAngle(a.getStartAngle() + 5);
                }
        }

        public void ReverseRotate(){
            for (int i = 0; i < 4; i++) {
                Arc a = (Arc)bladeList.get(i);
                a.setStartAngle(a.getStartAngle() - 5);
            }
        }

    public static void main(String[] args) { launch(args); }
}
