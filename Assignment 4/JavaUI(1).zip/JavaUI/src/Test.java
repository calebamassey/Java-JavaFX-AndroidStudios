

// new Person()
//    .setName()
//    .getName()