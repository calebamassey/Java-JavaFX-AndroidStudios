package Number_14_9;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Arc;
import javafx.scene.shape.ArcType;
import javafx.scene.shape.Circle;
import javafx.stage.Stage;

public class Four_Fan extends Application {
    private int radius = 50;
    private int space = 10;
    GridPane pane = new GridPane();
    int x, y = radius + space;

    @Override
    public void start(Stage primaryStage) throws Exception {
        getCircles();
        Scene scene = new Scene(pane, 250, 250);
        primaryStage.setTitle("Four Fan");
        primaryStage.setScene(scene);
        primaryStage.show();

    }

    private void getCircles() {
        //This for loop is to go through the 2 columns
        for (int i = 0; i < 2; i++){
            //This for loop is to go through the 2 rows
            for (int j = 0; j < 2; j++){

                Circle circle = new Circle(radius);
                circle.setStroke(Color.BLACK);
                circle.setFill(Color.WHITE);
                circle.setCenterX(x );
                circle.setCenterY(y);
                GridPane.setColumnIndex(circle, i);
                GridPane.setRowIndex(circle, j);
                pane.getChildren().add(circle);
                getArcs(i, j);

                x += radius * 2 + space;
            }

            x = radius + space;
            y += radius * 2 + space;
        }

    }

    private void getArcs(int i, int j) {
        for (int a = 90; a <= 360; a+= 90 ) {
            Arc arc = new Arc(x , y, radius - 15, radius - 15, a, 30);
            switch (a){
                case 90:
                    arc.setFill(Color.RED);
                    break;
                case 180:
                    arc.setFill(Color.GREEN);
                    break;
                case 270:
                    arc.setFill(Color.BLUE);
                    break;
                case 360:
                    arc.setFill(Color.BLACK);
                    break;
            }
            arc.setType(ArcType.ROUND);
            GridPane.setColumnIndex(arc, i);
            GridPane.setRowIndex(arc, j);
            pane.getChildren().add(arc);
        }
    }

    public static void main(String[] args) {
        Application.launch(args);
    }



}
