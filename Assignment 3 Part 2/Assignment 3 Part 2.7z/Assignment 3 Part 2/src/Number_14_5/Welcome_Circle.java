package Number_14_5;

import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.Pane;
import javafx.scene.text.Text;
import javafx.scene.text.Font;
import javafx.stage.Stage;

import java.awt.*;
import java.sql.Time;
import java.util.concurrent.Flow;

public class Welcome_Circle extends Application {
    @Override
    public void start(Stage primaryStage) throws Exception {

        Pane pane = new Pane();
       // pane.setAlignment(Pos.CENTER);

       // String[] s = {"W","e","l","c","o","m","e"," ","t","o"," ","J","a","v","a"};
        String phrase = "Welcome to Java ";
        String[] s = phrase.split("");
        for (int i = 0; i < s.length; i++)
        {
            double radius = 50;
            double alpha = 2 * Math.PI * (s.length - i) / s.length;
            Text txt = new Text(radius * Math.cos(alpha) + 120,
                    120 - radius * Math.sin(alpha), s[i] + "");

            txt.setFont(new Font("TimesRoman", 15));
            txt.setRotate(360 * i / s.length + 90);
           // txt.setTextAlignment(Math.PI/i);
            pane.getChildren().add(txt);
        }

        Scene scene = new Scene(pane, 250, 250);
        primaryStage.setTitle("Welcome Circle");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    public static void main(String[] args) {
    Application.launch(args);
    }
}
