package Number_14_11;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Arc;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Ellipse;
import javafx.stage.Stage;

public class Smiley extends Application {

    int radius = 50;

    @Override
    public void start(Stage primaryStage) throws Exception {

        Pane pane = new Pane();


        //Make Head
        Circle circle = new Circle(100, 100, radius, Color.TRANSPARENT);
        circle.setStroke(Color.BLACK);
        pane.getChildren().add(circle);

        //Make Eyes
        Circle right_eye = new Circle(80, 80, 12, Color.WHITE);
        Circle left_eye = new Circle(120, 80, 12, Color.WHITE);
        right_eye.setStroke(Color.BLACK);
        left_eye.setStroke(Color.BLACK);
        pane.getChildren().add(right_eye);
        pane.getChildren().add(left_eye);

        //Make Pupil
        Circle pupil1 = new Circle(80, 80, 4, Color.BLACK);
        Circle pupil2 = new Circle(120, 80, 4, Color.BLACK);
        pane.getChildren().add(pupil1);
        pane.getChildren().add(pupil2);

        //Make Mouth
        Arc mouth = new Arc(20, 150, 100, 80, 0, 20);
        mouth.rotateProperty();
        pane.getChildren().add(mouth);

        //Make Nose
        

        Scene scene = new Scene(pane, 250, 250);
        primaryStage.setTitle("Smiley Face");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    public static void main(String[] args) {
        Application.launch(args);
    }

}
