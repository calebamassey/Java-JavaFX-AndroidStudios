package demoproject.caleb.umbc.chapter_5_cityguide;

import android.os.Bundle;
import android.app.Activity;

public class Willis extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_willis);
    }

}
