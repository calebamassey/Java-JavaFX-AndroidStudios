package Problem_16_10;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class Text_Viewer extends Application {
    BorderPane pane = new BorderPane();
    HBox textBar = new HBox();
    Button btView = new Button("View");
    TextField tfText = new TextField();
    TextArea taOutput = new TextArea();

    @Override
    public void start(Stage primaryStage) throws Exception {

        taOutput.setEditable(false);

        tfText.setPrefColumnCount(40);
        tfText.setText("Enter File Name");
        btView.setOnAction(e -> {
            File file = new File(tfText.getText());
            if (file.exists()) {
                String outputText = "";
                try (
                    Scanner input = new Scanner(file);
                ){
                    while(input.hasNextLine()){
                        outputText += input.nextLine() +"\n";
                    }
                    taOutput.setText(outputText);
                } catch (FileNotFoundException e1) {
                    e1.printStackTrace();
                }
            }
            else{
                taOutput.setText("ERROR: NO SUCH FILE");
            }
        });

        textBar.getChildren().addAll(tfText, btView);
        pane.setCenter(taOutput);
        pane.setBottom(textBar);

        Scene scene= new Scene(pane, 505, 250);
        primaryStage.setTitle("Text Viewer");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    public static void main(String[] args) { launch(args); }
}
