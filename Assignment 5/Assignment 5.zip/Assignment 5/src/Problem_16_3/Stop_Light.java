package Problem_16_3;

import javafx.application.Application;
import javafx.geometry.Orientation;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.RadioButton;
import javafx.scene.control.ToggleGroup;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;

public class Stop_Light extends Application {
    BorderPane pane = new BorderPane();
    Circle green = new Circle(50, Color.TRANSPARENT);
    Circle yellow = new Circle(50, Color.TRANSPARENT);
    Circle red = new Circle(50, Color.TRANSPARENT);
    HBox buttons = new HBox(20);
    FlowPane circle = new FlowPane();
    StackPane light = new StackPane();
    Rectangle rect = new Rectangle(200, 400);

    @Override
    public void start(Stage primaryStage) throws Exception {

        green.setStroke(Color.BLACK);
        yellow.setStroke(Color.BLACK);
        red.setStroke(Color.BLACK);

        RadioButton rbGreen = new RadioButton("Green");
        RadioButton rbYellow = new RadioButton("Yellow");
        RadioButton rbRed = new RadioButton("Red");

        rect.setFill(Color.GRAY);
        rect.setStroke(Color.BLACK);

        buttons.getChildren().addAll(rbGreen, rbYellow, rbRed);
        buttons.setAlignment(Pos.CENTER);
        circle.getChildren().addAll(green, yellow, red);
        circle.setOrientation(Orientation.VERTICAL);
        circle.setAlignment(Pos.CENTER);

        light.getChildren().add(rect);
        light.getChildren().add(circle);
        pane.setCenter(light);
        pane.setBottom(buttons);

        ToggleGroup group = new ToggleGroup();

        rbGreen.setToggleGroup(group);
        rbYellow.setToggleGroup(group);
        rbRed.setToggleGroup(group);

        rbGreen.setOnAction(e -> {
            green.setFill(Color.GREEN);
            yellow.setFill(Color.TRANSPARENT);
            red.setFill(Color.TRANSPARENT);
        });
        rbYellow.setOnAction(e -> {
            green.setFill(Color.TRANSPARENT);
            yellow.setFill(Color.YELLOW);
            red.setFill(Color.TRANSPARENT);
        });
        rbRed.setOnAction(e -> {
            green.setFill(Color.TRANSPARENT);
            yellow.setFill(Color.TRANSPARENT);
            red.setFill(Color.RED);
        });

        Scene scene = new Scene(pane, 500, 500);
        primaryStage.setTitle("Stop Light");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    public void makeCircles(){



    }

    public static void main(String[] args) { launch(args); }
}
