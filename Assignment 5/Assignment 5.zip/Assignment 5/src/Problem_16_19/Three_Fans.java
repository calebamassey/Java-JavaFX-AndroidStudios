package Problem_16_19;

import javafx.animation.KeyFrame;
import javafx.animation.KeyValue;
import javafx.animation.PathTransition;
import javafx.animation.Timeline;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.shape.Arc;
import javafx.scene.shape.ArcType;
import javafx.scene.shape.Circle;
import javafx.stage.Stage;
import javafx.util.Duration;

import java.util.ArrayList;

public class Three_Fans extends Application {
    private BorderPane pane = new BorderPane();
    private Timeline motion;
    private Integer count = 0;


    @Override
    public void start(Stage primaryStage) throws Exception {
        HBox buttons = new HBox();
        Button btStartAll = new Button("Start All");
        Button btStopAll = new Button("Stop All");

        buttons.getChildren().addAll(btStartAll, btStopAll);
        buttons.setAlignment(Pos.CENTER);

        StackPane paneLeft = new StackPane();
        paneLeft.getChildren().add(createFan());
        StackPane paneCenter = new StackPane();
        paneCenter.getChildren().add(createFan());
        StackPane paneRight = new StackPane();
        paneRight.getChildren().add(createFan());


        HBox threeFanPane = new HBox();
        threeFanPane.getChildren().addAll(paneLeft, paneCenter, paneRight);
        threeFanPane.setAlignment(Pos.CENTER);


        btStartAll.setOnAction( e -> {
            for (Node fans : threeFanPane.getChildren()){

            }
        });

        btStopAll.setOnAction( e -> {
            for (Node fans : threeFanPane.getChildren()){
                Pause();
            }
        });

        pane.setCenter(threeFanPane);
        pane.setBottom(buttons);

        Scene scene = new Scene(pane, 600, 600);
        primaryStage.setScene(scene);
        primaryStage.setTitle("Moving Fan");
        primaryStage.show();

    }

    public BorderPane createFan(){
        count++;
        BorderPane fanPane = new BorderPane();

        Button btRun = new Button("Resume");
        Button btPause = new Button("Pause");
        Button btReverse = new Button("Reverse");

        HBox buttons = new HBox();

        buttons.getChildren().add(btRun);
        buttons.getChildren().add(btReverse);
        buttons.getChildren().add(btPause);
        buttons.setAlignment(Pos.CENTER);
        buttons.setSpacing(5);

        Pane fan = new Pane();

        Circle circle = new Circle( 50);
        circle.setCenterX((100 * count));
        circle.setCenterY(150);
        circle.setStroke(Color.BLACK);
        circle.setFill(Color.WHITE);
        fan.getChildren().add(circle);

        ArrayList bladeList = new ArrayList();

        fan.getChildren().addAll(createBlades(bladeList));

        fanPane.setTop(buttons);
        fanPane.setCenter(fan);

        motion = new Timeline(new KeyFrame(Duration.millis(50), e -> Rotate(bladeList)));
        motion.setCycleCount(Timeline.INDEFINITE);
        motion.play();

        btRun.setOnAction(e -> Run(bladeList));
        btPause.setOnAction(e -> Pause());
        btReverse.setOnAction(e -> Reverse(bladeList));

        return fanPane;

    }

    public ArrayList createBlades(ArrayList bladeList) {
        Arc blade = new Arc();
        for (int i = 0; i < 4; i++) {
            switch (i){
                case 0:
                    blade = new Arc(100 * count, 150, 45, 45, 90, 40);
                    blade.setStroke(Color.BLACK);
                    blade.setFill(Color.BLACK);
                    blade.setType(ArcType.ROUND);
                    bladeList.add(blade);
                    break;
                case 1:
                    blade = new Arc(100 * count, 150, 45, 45, 180, 40);
                    blade.setStroke(Color.BLACK);
                    blade.setFill(Color.BLACK);
                    blade.setType(ArcType.ROUND);
                    bladeList.add(blade);
                    break;
                case 2:
                    blade = new Arc(100 * count, 150, 45, 45, 270, 40);
                    blade.setStroke(Color.BLACK);
                    blade.setFill(Color.BLACK);
                    blade.setType(ArcType.ROUND);
                    bladeList.add(blade);
                    break;
                case 3:
                    blade = new Arc(100 * count, 150, 45, 45, 360, 40);
                    blade.setStroke(Color.BLACK);
                    blade.setFill(Color.BLACK);
                    blade.setType(ArcType.ROUND);
                    bladeList.add(blade);
                    break;
            }
        }
        return bladeList;
    }


    public void Run(ArrayList bladeList){
        motion.pause();
        motion = new Timeline(new KeyFrame(Duration.millis(50), e -> Rotate(bladeList)));
        motion.setCycleCount(Timeline.INDEFINITE);
        motion.play();
    }

    public void Pause(){
        motion.pause();
    }


    public void Reverse(ArrayList bladeList){
        motion.pause();
        motion = new Timeline(new KeyFrame(Duration.millis(50), e -> ReverseRotate(bladeList)));
        motion.setCycleCount(Timeline.INDEFINITE);
        motion.play();
    }

    public void Rotate(ArrayList bladeList){
        for (int i = 0; i < 4; i++) {
            Arc a = (Arc)bladeList.get(i);
            a.setStartAngle(a.getStartAngle() + 5);
        }
    }

    public void ReverseRotate(ArrayList bladeList){
        for (int i = 0; i < 4; i++) {
            Arc a = (Arc)bladeList.get(i);
            a.setStartAngle(a.getStartAngle() - 5);
        }
    }

    public static void main(String[] args) { launch(args); }
}

