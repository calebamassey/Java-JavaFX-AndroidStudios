package Problem_16_5;

import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

public class Number_Converter extends Application {
    GridPane pane = new GridPane();
    Label decLabel = new Label("Decimal");
    Label hexLabel = new Label("Hex");
    Label binLabel = new Label("Binary");
    TextField tfDecimal = new TextField();
    TextField tfHex = new TextField();
    TextField tfBin = new TextField();

    @Override
    public void start(Stage primaryStage) throws Exception {

        tfDecimal.setOnAction(e -> {
            tfHex.setText(Integer.toHexString(Integer.parseInt(tfDecimal.getText())));
            tfBin.setText(Integer.toBinaryString(Integer.parseInt(tfDecimal.getText())));

        });
        tfHex.setOnAction(e -> {
            tfDecimal.setText(String.valueOf(Integer.parseInt(tfHex.getText(), 16)));
            tfBin.setText(Integer.toBinaryString(Integer.parseInt(tfHex.getText(), 16)));
        });
        tfBin.setOnAction(e -> {
            tfDecimal.setText(String.valueOf(Integer.parseInt(tfBin.getText(), 2)));
            tfHex.setText(Integer.toHexString(Integer.parseInt(tfBin.getText(), 2)));
        });

        pane.add(decLabel, 0, 0);
        pane.add(tfDecimal, 1, 0);
        pane.add(hexLabel, 0,1);
        pane.add(tfHex, 1,1);
        pane.add(binLabel, 0,2);
        pane.add(tfBin, 1,2);

        pane.setHgap(15);
        pane.setVgap(20);
        pane.setAlignment(Pos.CENTER);

        Scene scene = new Scene(pane, 300, 200);
        primaryStage.setTitle("Number Converter");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    public static void main(String[] args) { launch(args); }
}
