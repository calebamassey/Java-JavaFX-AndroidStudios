package Problem_16_14;

import javafx.application.Application;
import javafx.collections.ObservableList;
import javafx.geometry.Pos;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Stage;

import static javafx.scene.text.Font.font;

public class Select_Font extends Application {
    BorderPane pane = new BorderPane();
    StackPane displayArea = new StackPane();
    HBox topBar = new HBox();
    HBox bottomBar = new HBox();

    @Override
    public void start(Stage primaryStage) throws Exception {
        Label lbFont = new Label("Font Name");
        Label lbSize = new Label("Font Size");
        Label lbBold = new Label("Bold");
        Label lbItalic = new Label("Italic");
        CheckBox chBold = new CheckBox();
        CheckBox chItalic = new CheckBox();

        Text text = new Text("Programming is fun");
        String family = new String("Times New Roman");
        Integer size = 20;
        FontPosture italic = FontPosture.REGULAR;
        FontWeight bold = FontWeight.NORMAL;
        text.setFont(Font.font(family, bold, italic, size));

        ComboBox cbFont = new ComboBox();
        cbFont.getItems().addAll(Font.getFamilies());
        ComboBox cbSize = new ComboBox();
        for (int i = 0; i <= 100; ++i) {
            cbSize.getItems().addAll(i);
        }

        cbFont.setOnAction(e -> {
            if (cbSize.getValue() == null){
                text.setFont(font((String)cbFont.getValue(), size));
            }
            else{
                text.setFont(font((String)cbFont.getValue(),(Integer)cbSize.getValue()));
            }
        });

        cbSize.setOnAction(e -> {
            if(cbFont.getValue() == null){

                text.setFont(font(family, (Integer)cbSize.getValue()));
            }
            else{
                text.setFont(font((String) cbFont.getValue(), (Integer) cbSize.getValue()));
            }
        });



        chBold.setOnAction(e -> {
            if (chBold.isSelected()) {
                if (chItalic.isSelected()) {
                    if (cbFont != null && cbSize == null) {
                       text.setFont(Font.font((String) cbFont.getValue(), FontWeight.BOLD, FontPosture.ITALIC, size));
                    } else if (cbFont == null && cbSize != null) {
                       text.setFont(Font.font(family, FontWeight.BOLD, FontPosture.ITALIC, (Integer) cbSize.getValue()));
                    } else {
                       text.setFont(Font.font((String) cbFont.getValue(), FontWeight.BOLD, FontPosture.ITALIC, (Integer) cbSize.getValue()));
                    }
                } else {
                    if (cbFont != null && cbSize == null) {
                       text.setFont(Font.font((String) cbFont.getValue(), FontWeight.BOLD, FontPosture.REGULAR, size));
                    } else if (cbFont == null && cbSize != null) {
                       text.setFont(Font.font(family, FontWeight.BOLD, FontPosture.REGULAR, (Integer) cbSize.getValue()));
                    } else {
                       text.setFont(Font.font((String) cbFont.getValue(), FontWeight.BOLD, FontPosture.REGULAR, (Integer) cbSize.getValue()));
                    }
                }
            }
            else{
                if (chItalic.isSelected()) {
                    if (cbFont != null && cbSize == null) {
                       text.setFont(Font.font((String) cbFont.getValue(), FontWeight.BOLD, FontPosture.REGULAR, size));
                    } else if (cbFont == null && cbSize != null) {
                       text.setFont(Font.font(family, FontWeight.BOLD, FontPosture.REGULAR, (Integer) cbSize.getValue()));
                    } else {
                       text.setFont(Font.font((String) cbFont.getValue(), FontWeight.BOLD, FontPosture.REGULAR, (Integer) cbSize.getValue()));
                    }
                } else {
                    if (cbFont != null && cbSize == null) {
                       text.setFont(Font.font((String) cbFont.getValue(), FontWeight.NORMAL, FontPosture.REGULAR, size));
                    } else if (cbFont == null && cbSize != null) {
                       text.setFont(Font.font(family, FontWeight.NORMAL, FontPosture.REGULAR, (Integer) cbSize.getValue()));
                    } else {
                       text.setFont(Font.font((String) cbFont.getValue(), FontWeight.NORMAL, FontPosture.REGULAR, (Integer) cbSize.getValue()));
                    }
                }
            }
        });

        chItalic.setOnAction(e -> {
            if (chItalic.isSelected()) {
                if (chBold.isSelected()) {
                    if (cbFont != null && cbSize == null) {
                       text.setFont(Font.font((String) cbFont.getValue(), FontWeight.BOLD, FontPosture.ITALIC, size));
                    } else if (cbFont == null && cbSize != null) {
                       text.setFont(Font.font(family, FontWeight.BOLD, FontPosture.ITALIC, (Integer) cbSize.getValue()));
                    } else {
                       text.setFont(Font.font((String) cbFont.getValue(), FontWeight.BOLD, FontPosture.ITALIC, (Integer) cbSize.getValue()));
                    }
                } else {
                    if (cbFont != null && cbSize == null) {
                       text.setFont(Font.font((String) cbFont.getValue(), FontWeight.NORMAL, FontPosture.ITALIC, size));
                    } else if (cbFont == null && cbSize != null) {
                       text.setFont(Font.font(family, FontWeight.NORMAL, FontPosture.ITALIC, (Integer) cbSize.getValue()));
                    } else {
                       text.setFont(Font.font((String) cbFont.getValue(), FontWeight.NORMAL, FontPosture.ITALIC, (Integer) cbSize.getValue()));
                    }
                }
            }
            else{
                if (chBold.isSelected()) {
                    if (cbFont != null && cbSize == null) {
                       text.setFont(Font.font((String) cbFont.getValue(), FontWeight.BOLD, FontPosture.REGULAR, size));
                    } else if (cbFont == null && cbSize != null) {
                       text.setFont(Font.font(family, FontWeight.BOLD, FontPosture.REGULAR, (Integer) cbSize.getValue()));
                    } else {
                       text.setFont(Font.font((String) cbFont.getValue(), FontWeight.BOLD, FontPosture.REGULAR, (Integer) cbSize.getValue()));
                    }
                } else {
                    if (cbFont != null && cbSize == null) {
                       text.setFont(Font.font((String) cbFont.getValue(), FontWeight.NORMAL, FontPosture.REGULAR, size));
                    } else if (cbFont == null && cbSize != null) {
                       text.setFont(Font.font(family, FontWeight.NORMAL, FontPosture.REGULAR, (Integer) cbSize.getValue()));
                    } else {
                       text.setFont(Font.font((String) cbFont.getValue(), FontWeight.NORMAL, FontPosture.REGULAR, (Integer) cbSize.getValue()));
                    }
                }
            }
        });


        topBar.getChildren().addAll(lbFont, cbFont, lbSize, cbSize);
        topBar.setAlignment(Pos.CENTER);
        topBar.setSpacing(10);
        pane.setTop(topBar);
        bottomBar.getChildren().addAll(chBold, lbBold, chItalic, lbItalic);
        bottomBar.setAlignment(Pos.CENTER);
        bottomBar.setSpacing(10);
        pane.setBottom(bottomBar);
        displayArea.getChildren().add(text);
        pane.setCenter(displayArea);

        Scene scene = new Scene(pane, 500, 500);
        primaryStage.setScene(scene);
        primaryStage.setTitle("Select a Font");
        primaryStage.show();
    }

    public static void main(String[] args) { launch(args); }
}
