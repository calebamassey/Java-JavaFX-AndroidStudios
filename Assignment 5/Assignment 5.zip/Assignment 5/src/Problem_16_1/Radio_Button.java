package Problem_16_1;

import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.ToggleGroup;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import javafx.scene.control.RadioButton;

public class Radio_Button extends Text_Pane {
    protected BorderPane getPane() {
        HBox radioPane = new HBox(10);
        BorderPane pane = super.getPane();
        HBox buttons = new HBox(15);

        RadioButton rbRed = new RadioButton("Red");
        RadioButton rbOrange = new RadioButton("Orange");
        RadioButton rbGreen = new RadioButton("Green");
        RadioButton rbBlack = new RadioButton("Black");
        RadioButton rbBlue = new RadioButton("Blue");

        rbRed.setOnAction(e -> text.setFill(Color.RED));
        rbOrange.setOnAction(e -> text.setFill(Color.ORANGE));
        rbGreen.setOnAction(e -> text.setFill(Color.GREEN));
        rbBlack.setOnAction(e -> text.setFill(Color.BLACK));
        rbBlue.setOnAction(e -> text.setFill(Color.BLUE));

        buttons.getChildren().addAll(rbRed, rbOrange, rbGreen, rbBlack, rbBlue);
        buttons.setAlignment(Pos.CENTER);

        ToggleGroup group = new ToggleGroup();
        rbRed.setToggleGroup(group);
        rbOrange.setToggleGroup(group);
        rbGreen.setToggleGroup(group);
        rbBlack.setToggleGroup(group);
        rbBlue.setToggleGroup(group);

        pane.setTop(buttons);
        return pane;
    }

        public static void main (String[]args){
            launch(args);
        }
}
