package Problem_16_1;

import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class Text_Pane extends Application {
    protected Text text = new Text(250, 250, "Javafx Text");

        protected BorderPane getPane(){
            BorderPane pane = new BorderPane();
            HBox buttons = new HBox(15);
            Button btLeft = new Button("Left");
            Button btRight = new Button("Right");
            Button btUp = new Button("Up");
            Button btDown = new Button("Down");

            btLeft.setOnAction(e -> {
                if (text.getX() > 10)
                    text.setX(text.getX() - 10);
                else{
                 text.setX(text.getX());
                }
            });
            btRight.setOnAction(e -> {
                if (text.getX() < 490)
                    text.setX(text.getX() + 10);
                else{
                    text.setX(text.getX());
                }
            });
            btDown.setOnAction(e -> {
                if (text.getY() < 490)
                    text.setY(text.getY() + 10);
                else{
                    text.setY(text.getY());
                }
            });
            btUp.setOnAction(e -> {
                if (text.getY() > 10)
                    text.setY(text.getY() - 10);
                else{
                    text.setY(text.getY());
                }
            });

            buttons.setAlignment(Pos.CENTER);
            buttons.getChildren().addAll(btLeft, btRight, btDown, btUp);
            pane.setBottom(buttons);
            pane.getChildren().add(text);

            return pane;
        }

        @Override
        public void start(Stage primaryStage) throws Exception {
            Pane pane = getPane();
            Scene scene = new Scene(pane, 500, 500);
            primaryStage.setScene(scene);
            primaryStage.setTitle("Radio Button");
            primaryStage.show();
    }

    public static void main(String[] args) { launch(args); }
}
