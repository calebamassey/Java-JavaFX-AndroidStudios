package Problem_16_22;

import javafx.application.Application;
import javafx.geometry.Orientation;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.FlowPane;
import javafx.scene.media.AudioClip;
import javafx.stage.Stage;

import static javafx.scene.media.AudioClip.INDEFINITE;

public class Audio_Loop extends Application {
    FlowPane pane = new FlowPane();

    @Override
    public void start(Stage primaryStage) throws Exception {

        AudioClip audio = new AudioClip("C:/Users/caleb/OneDrive/Documents/Documents Files/Fall 2018/IS 413 GUI Systems Using JAVA/book/audio/china.mp3");
        Button btPlay = new Button("Play");
        btPlay.setOnAction(e ->{
            audio.play();
        });
        Button btLoop = new Button("Loop");
        btLoop.setOnAction(e -> {
            audio.stop();
            audio.setCycleCount(INDEFINITE);
            audio.play();
        });
        Button btStop = new Button("Stop");
        btStop.setOnAction(e -> {
            audio.stop();
        });

        pane.getChildren().addAll(btPlay, btLoop, btStop);
        pane.setAlignment(Pos.CENTER);
        pane.setOrientation(Orientation.HORIZONTAL);
        pane.setHgap(10);

        Scene scene = new Scene(pane, 300, 200);
        primaryStage.setScene(scene);
        primaryStage.setTitle("Audio Loop");
        primaryStage.show();
    }

    public static void main(String[] args) { launch(args); }
}
