package Problem_16_13;

import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.stage.Stage;

import javax.swing.border.Border;

public class Loan_GUI extends Application {
    BorderPane pane = new BorderPane();
    HBox topBar = new HBox();
    Label lbLoan = new Label("Loan Amount");
    TextField tfLoan = new TextField();
    Label lbYears = new Label("Number of Years");
    TextField tfYears = new TextField();
    Button btDisplay = new Button("Show Table");
    TextArea taInterest = new TextArea();
    TextArea taMonthPay = new TextArea();
    TextArea taYearPay = new TextArea();
    GridPane formatText = new GridPane();

    @Override
    public void start(Stage primaryStage) throws Exception {

        //taInterest.setPrefColumnCount(3);

        taInterest.setEditable(false);
        taMonthPay.setEditable(false);
        taYearPay.setEditable(false);

        btDisplay.setOnAction(e -> {
            String tempIR = "Interest Rate" + "\n";
            String tempMo = "Monthly Payment" + "\n";
            String tempYr = "Yearly Payment" + "\n";
            for (double IR = 5; IR <=8; IR = IR + 0.125){
                tempIR += IR + "\n";
              //  tempMo += IR *
            }
            taInterest.setText(tempIR);
            formatText.add(taInterest, 0, 0);
            formatText.add(taMonthPay, 1, 0);
            formatText.add(taYearPay, 2, 0);
        });

        topBar.getChildren().addAll(lbLoan, tfLoan, lbYears, tfYears, btDisplay);
        topBar.setAlignment(Pos.CENTER);
        topBar.setSpacing(10);

        pane.setTop(topBar);
        pane.setCenter(formatText);

        Scene scene = new Scene(pane, 750, 500);
        primaryStage.setScene(scene);
        primaryStage.setTitle("Loan GUI");
        primaryStage.show();
    }

    public static void main(String[] args) { launch(args); }
}
