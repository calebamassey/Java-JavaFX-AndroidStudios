package Problem_16_17;

import javafx.application.Application;
import javafx.geometry.Orientation;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.Slider;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Pane;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.stage.Stage;


public class Color_Sliders extends Application {
   BorderPane pane = new BorderPane();
   GridPane centerPane = new GridPane();
   StackPane textPane = new StackPane();

    @Override
    public void start(Stage primaryStage) throws Exception {

        Label lbRed = new Label("Red");
        Label lbGreen = new Label("Green");
        Label lbBlue = new Label("Blue");
        Label lbOpac = new Label("Opacity");

        Slider slRed = new Slider();
        slRed.setValue(0.5);
        Slider slGreen = new Slider();
        slGreen.setValue(0.5);
        Slider slBlue = new Slider();
        slBlue.setValue(0.5);
        Slider slOpac = new Slider();
        slOpac.setValue(0.5);

        slRed.setMin(0);
        slRed.setMax(1.0);
        slGreen.setMin(0);
        slGreen.setMax(1.0);
        slBlue.setMin(0);
        slBlue.setMax(1.0);
        slOpac.setMin(0);
        slOpac.setMax(1.0);

        slRed.setOrientation(Orientation.HORIZONTAL);
        slGreen.setOrientation(Orientation.HORIZONTAL);
        slBlue.setOrientation(Orientation.HORIZONTAL);
        slOpac.setOrientation(Orientation.HORIZONTAL);

        slRed.setShowTickMarks(true);
        slGreen.setShowTickMarks(true);
        slBlue.setShowTickMarks(true);
        slOpac.setShowTickMarks(true);

        Text text = new Text("Show Colors");
        text.setFont(Font.font(30));
        text.setFill( Color.color(slRed.getValue(), slGreen.getValue(), slBlue.getValue(), slOpac.getValue()));

       slRed.valueProperty().addListener(e ->{
            text.setFill( Color.color(slRed.getValue(), slGreen.getValue(), slBlue.getValue(), slOpac.getValue()));
        } );
        slGreen.valueProperty().addListener(e ->{
            text.setFill( Color.color(slRed.getValue(), slGreen.getValue(), slBlue.getValue(), slOpac.getValue()));
        } );
        slBlue.valueProperty().addListener(e ->{
            text.setFill( Color.color(slRed.getValue(), slGreen.getValue(), slBlue.getValue(), slOpac.getValue()));
        } );
        slOpac.valueProperty().addListener(e ->{
            text.setFill( Color.color(slRed.getValue(), slGreen.getValue(), slBlue.getValue(), slOpac.getValue()));
        } );

        centerPane.add(lbRed, 0, 0);
        centerPane.add(slRed, 1, 0);
        centerPane.add(lbGreen, 0, 1);
        centerPane.add(slGreen, 1, 1);
        centerPane.add(lbBlue, 0, 2);
        centerPane.add(slBlue, 1, 2);
        centerPane.add(lbOpac, 0, 3);
        centerPane.add(slOpac, 1, 3);

        centerPane.setVgap(10);
        centerPane.setHgap(10);
        centerPane.setAlignment(Pos.CENTER);

        textPane.getChildren().add(text);
        textPane.setAlignment(Pos.CENTER);

        pane.setCenter(centerPane);
        pane.setTop(textPane);

        Scene scene = new Scene(pane, 300, 300);
        primaryStage.setTitle("Color Sliders");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    public static void main(String[] args) { launch(args); }
}
