package Problem_16_4;

import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;
import javafx.util.converter.DoubleStringConverter;

public class Mile_Converter extends Application {
    GridPane pane = new GridPane();
    Label mileLabel = new Label("Miles");
    Label kiloLabel = new Label("Kilometers");
    double kilometers;
    double miles;

    @Override
    public void start(Stage primaryStage) throws Exception {

        TextField tfMiles = new TextField();
        TextField tfKilometers = new TextField();
        tfKilometers.setEditable(false);

        tfMiles.setOnAction( e -> {
            miles = Double.valueOf(tfMiles.getText());
            kilometers = miles * 1.60934;
            String text = String.valueOf(kilometers);
            tfKilometers.setText(text);
        });

        pane.add(mileLabel, 0, 0);
        pane.add(kiloLabel,0,1);
        pane.add(tfMiles, 1, 0);
        pane.add(tfKilometers, 1, 1);

        pane.setVgap(15);
        pane.setHgap(20);
        pane.setAlignment(Pos.CENTER);

        Scene scene = new Scene(pane, 300, 100);
        primaryStage.setScene(scene);
        primaryStage.setTitle("Mile Converter");
        primaryStage.show();
    }

    public static void main(String[] args) { launch(args); }
}
