package Problem_16_7;

import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.text.Text;
import javafx.stage.Stage;


public class Clock_with_Textfields extends Application {
    HBox inputs = new HBox();
    StackPane clock = new StackPane();
    BorderPane pane = new BorderPane();
    TextField tfHours = new TextField();
    TextField tfMinutes = new TextField();
    TextField tfSeconds = new TextField();
    Label hourLabel = new Label("Hour");
    Label minuteLabel = new Label("Minutes");
    Label secondLabel = new Label("Seconds");

    @Override
    public void start(Stage primaryStage) throws Exception {

        createClock();

        tfHours.setOnAction(e -> {

        });

        tfMinutes.setOnAction(e -> {

        });

        tfSeconds.setOnAction(e -> {

        });

        tfHours.setPrefColumnCount(2);
        tfMinutes.setPrefColumnCount(2);
        tfSeconds.setPrefColumnCount(2);

        inputs.getChildren().addAll(hourLabel, tfHours, minuteLabel, tfMinutes, secondLabel, tfSeconds);
        inputs.setAlignment(Pos.CENTER);
        inputs.setSpacing(10);

        pane.setCenter(clock);
        pane.setBottom(inputs);
        Scene scene = new Scene(pane, 500, 500);
        primaryStage.setScene(scene);
        primaryStage.setTitle("Clock with Textfields");
        primaryStage.show();
    }

    protected void createClock(){
        Circle circle = new Circle(250, 250, 60);
        circle.setStroke(Color.BLACK);
        circle.setFill(Color.TRANSPARENT);

        Pane texts = new Pane();
        Text t1 = new Text(circle.getCenterX() - 5, circle.getCenterY() - circle.getRadius() + 5, "12");
        Text t2 = new Text(circle.getCenterX() - circle.getRadius() + 5, circle.getCenterY() + 5, "9");
        Text t3 = new Text(circle.getCenterX() + circle.getRadius() - 5, circle.getCenterY() + 5, "3");
        Text t4 = new Text(circle.getCenterX() - 5, circle.getCenterY() + circle.getRadius() - 5, "6");
        texts.getChildren().addAll(t1, t2, t3, t4);
        clock.getChildren().addAll(circle, texts);
    }

    public static void main(String[] args) { launch(args); }
}
