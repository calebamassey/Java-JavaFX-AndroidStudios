package demoproject.caleb.umbc.android_bootcamp_project.Chapter_5.BikeRental;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

import demoproject.caleb.umbc.android_bootcamp_project.R;

public class Beach extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.ch5_bike_beach);
    }

}
