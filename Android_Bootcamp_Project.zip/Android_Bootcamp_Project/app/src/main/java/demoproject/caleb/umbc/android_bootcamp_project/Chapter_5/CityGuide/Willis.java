package demoproject.caleb.umbc.android_bootcamp_project.Chapter_5.CityGuide;

import android.app.Activity;
import android.os.Bundle;

import demoproject.caleb.umbc.android_bootcamp_project.R;

public class Willis extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.ch5_city_willis);
    }

}
