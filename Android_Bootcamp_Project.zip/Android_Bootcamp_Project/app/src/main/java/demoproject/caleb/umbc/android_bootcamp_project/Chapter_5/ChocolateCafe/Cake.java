package demoproject.caleb.umbc.android_bootcamp_project.Chapter_5.ChocolateCafe;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

import demoproject.caleb.umbc.android_bootcamp_project.R;

public class Cake extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.ch5_chocolatecafe_cake);
    }
}
