package Assignment_9_13_2018.Number_13_9;

public interface Colorable {

    boolean equals(Circle13_09 circle);

    public void howToColor();


}

