package Assignment_9_13_2018.Number_13_7;

public interface Colorable {

    public void howToColor();


}

