package demoproject.caleb.umbc.chapter2youthhostelapp;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

public class Information_Page extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.information_layout);

    }
}
