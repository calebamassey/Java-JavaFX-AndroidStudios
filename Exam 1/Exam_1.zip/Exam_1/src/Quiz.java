import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ToggleGroup;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.stage.Stage;
import javafx.scene.control.RadioButton;


public class Quiz extends Application {
VBox pane = new VBox(5);
Label lbTitle = new Label("Quiz Question 1:");
Label lbQuestion = new Label("What is the range of short data typ in Java??");
RadioButton rbQuestion1 = new RadioButton("-32768 to 32767");
RadioButton rbQuestion2 = new RadioButton("-128 to 127");
RadioButton rbQuestion3 = new RadioButton("-2147483648 to 2147483647");
RadioButton rbQuestion4 = new RadioButton("Not enough information to answer the question.");
Button btSubmit = new Button("Submit");
Label wrong = new Label("Wrong Answer");
Label correct = new Label("Correct Answer");
ToggleGroup group = new ToggleGroup();
Insets insets = new Insets(10, 50, 50, 50);

    @Override
    public void start(Stage primaryStage) throws Exception {

        //Edit the Head Title of Quiz Question 1
        lbTitle.setFont(new Font("Serif", 30));
        Insets paddingTitle = new Insets(10, 10, 10, 10);
        lbTitle.setPadding(paddingTitle);
        lbTitle.setStyle("-fx-background-color: #ccffff;");
        lbTitle.setAlignment(Pos.CENTER);

        //Put the radiobuttons in a group
        rbQuestion1.setToggleGroup(group);
        rbQuestion2.setToggleGroup(group);
        rbQuestion3.setToggleGroup(group);
        rbQuestion4.setToggleGroup(group);

        //Edit the submit button
        btSubmit.setStyle("-fx-border-color: #ff0000;" + "-fx-border-width: 5;" + "");
        btSubmit.setDisable(true);

        //Set the Submit button to be enabled or disabled
        //based on the whether a button is selected or not
        rbQuestion1.setOnAction(e -> {
            if (rbQuestion1.isSelected()){
                btSubmit.setDisable(false);
            }
            else{
                btSubmit.setDisable(true);
            }
        });

        rbQuestion2.setOnAction(e -> {
            if (rbQuestion2.isSelected()){
                btSubmit.setDisable(false);
            }
            else{
                btSubmit.setDisable(true);
            }
        });

        rbQuestion3.setOnAction(e -> {
            if (rbQuestion3.isSelected()){
                btSubmit.setDisable(false);
            }
            else{
                btSubmit.setDisable(true);
            }
        });

        rbQuestion4.setOnAction(e -> {
            if (rbQuestion4.isSelected()){
                btSubmit.setDisable(false);
            }
            else{
                btSubmit.setDisable(true);
            }
        });

        //Add all the Nodes to the pane
        pane.getChildren().addAll(lbTitle);
        pane.getChildren().addAll(lbQuestion);
        pane.getChildren().addAll(rbQuestion1);
        pane.getChildren().addAll(rbQuestion2);
        pane.getChildren().addAll(rbQuestion3);
        pane.getChildren().addAll(rbQuestion4);
        pane.getChildren().addAll(btSubmit);

        //Edit the entire Pane
        pane.setPadding(insets);
        pane.setStyle("-fx-background-color: white;" + "-fx-border-color: black;");

        //Changes the label underneath the button depending on if
        //the correct button has been selected
        btSubmit.setOnAction(e-> {
            if (rbQuestion2.isSelected() || rbQuestion3.isSelected() || rbQuestion4.isSelected()){
                btSubmit.setStyle("-fx-border-color: #ff0000;" + "-fx-border-width: 5;");
                if (pane.getChildren().contains(wrong)) {
                    pane.getChildren().remove(wrong);
                    pane.getChildren().add(wrong);
                    btSubmit.setDisable(true);
                }
                else if (pane.getChildren().contains(correct)) {
                    pane.getChildren().remove(correct);
                    pane.getChildren().add(wrong);
                    btSubmit.setDisable(true);
                }
                else{
                    pane.getChildren().add(wrong);
                    btSubmit.setDisable(true);
                }
            }
            else if (rbQuestion1.isSelected()){
                btSubmit.setStyle("-fx-border-color: #4cff0c;" + "-fx-border-width: 5;");
                if (pane.getChildren().contains(wrong)) {
                    pane.getChildren().remove(wrong);
                    pane.getChildren().add(correct);
                    btSubmit.setDisable(true);
                }
                else if (pane.getChildren().contains(correct)) {
                    pane.getChildren().remove(correct);
                    pane.getChildren().add(correct);
                    btSubmit.setDisable(true);
                }
                else{
                    pane.getChildren().add(correct);
                    btSubmit.setDisable(true);
                }

            }
        });

        //Creates the scene and displays the Stage
        Scene scene = new Scene(pane, 350, 300);
        primaryStage.setTitle("Simple Quiz");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    public static void main(String[] args) { launch(args); }
}
